﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2
{
    public class Motherboard
    {
        int memorySlots;
        int powerConsumption;
        int pciSlots;
        string formFactor;
        int hardDriveLimit;
        string cpu;
        int memory;
        string graphicsCard;

        public Motherboard(int memorySlots, int powerConsumption,
            int pciSlots, string formFactor, int hardDriveLimit, string cpu, 
            int memory, string graphicsCard)
        {
            this.memorySlots = memorySlots;
            this.powerConsumption = powerConsumption;
            this.pciSlots = pciSlots;
            this.formFactor = formFactor;
            this.hardDriveLimit = hardDriveLimit;
            this.cpu = cpu;
            this.memory = memory;
            this.graphicsCard = graphicsCard;
        }

        public override string ToString()
        {
            return "Motherboard;" + memorySlots + " " + powerConsumption + " " + pciSlots +
                " " + formFactor + " "+ hardDriveLimit + " "+ cpu + " " + memory + " "+
                graphicsCard;
        }

        public int MemorySlots {
            get { return memorySlots;}
            set {
                memorySlots = value;
                if (memorySlots < 0)
                    throw new Exception("memory slots cannot be zero.");
                if (memorySlots > 20)
                    throw new Exception("too many memory slots");
                 }
        }

        public int PowerConsumption
        {
            get { return powerConsumption; }
            set
            {
                powerConsumption = value;
                if (powerConsumption < 0)
                    throw new Exception("Power Consumption cannot be zero.");
                if (powerConsumption > 1500)
                    throw new Exception("too many Power Consumption");
            }
        }

    }


}
