﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2
{
    public class CPU
    {
        double speed;
        string manufacturer;
        string socketType;
        int cachesize;
        int numberofCores;


        public CPU(double speed, string manufacturer,
             string socketType, int cachesize, int numberofCores)
        {
            this.speed = speed;
            this.manufacturer = manufacturer;
            this.socketType = socketType;
            this.cachesize = cachesize;
            this.numberofCores = numberofCores;
        }

        public override string ToString()
        {
            return "CPU;" + speed + " " + manufacturer + " " + socketType + " " +
                cachesize+" "+ numberofCores;
        }

    }
}
