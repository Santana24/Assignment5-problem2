﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2
{
    public class HardDrive
    {
        int capacity;
        string type;
        int readSpeed;
        double writeSpeed;

        public HardDrive(int capacity, string type,
            int readSpeed, int writeSpeed) 
        {
            this.capacity = capacity;
            this.type = type;
            this.readSpeed = readSpeed;
            this.writeSpeed = writeSpeed;
        }

        public override string ToString()
        {
            return "HardDrive;" + capacity + " " + type + " " + readSpeed + " " + writeSpeed;
        }
    }
}
