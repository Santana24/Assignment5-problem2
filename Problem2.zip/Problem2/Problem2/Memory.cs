﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2
{
    public class Memory
    {
        double readSpeed;
        double writeSpeed;
        string type;
        int amountGb;

        public Memory(double readSpeed, double writeSpeed,
            string type, int amountGb)
        {
            this.readSpeed = readSpeed;
            this.writeSpeed = writeSpeed;
            this.type = type;
            this.amountGb = amountGb;
        }

        public override string ToString()
        {
            return "Memory;" + readSpeed + " " + writeSpeed + " " + type +
                " " + amountGb;
        }
    }
}
