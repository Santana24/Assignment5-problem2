﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2
{
    public class GraphicsCard
    {
        int fanCount;
        double speed;
        int videoMemory;
        int numberCUDAcores;

        public GraphicsCard(int fanCount, double speed,
            int videoMemory, int numberCUDAcores)
        {
            this.fanCount = fanCount;
            this.speed = speed;
            this.videoMemory = videoMemory;
            this.numberCUDAcores = numberCUDAcores;
        }

        public override string ToString()
        {
            return "GraphicsCard;" + fanCount + " " + speed + " " + videoMemory +
                " " + numberCUDAcores;
        }
    }
}
