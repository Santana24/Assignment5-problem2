﻿using System;

namespace Problem2
{
    public class ComputerLibrary
    {
    }
}
