﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2
{
    public class Case
    {
        int length;
        int width;
        int height;
        int numberFans;
        int numberVents;

        public Case(int length, int width,
            int height, int numberFans, int numberVents)
        {
            this.length = length;
            this.width = width;
            this.height = height;
            this.numberFans = numberFans;
            this.numberVents = numberVents;
        }

        public override string ToString()
        {
            return "Case;" + length + " " + width + " " + height +
                " " + numberFans+" "+ numberVents;
        }
    }
}
