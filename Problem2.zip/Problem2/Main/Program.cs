﻿using System;
using Problem2;

namespace Main
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");


            try
            {
            HardDrive hd = new HardDrive(4,"SSD", 2,3);
            Motherboard mb = new Motherboard(2,150,4,"formFactor",500,"CPU", 250,"Graphics Card");
            CPU cpu = new CPU(10.2,"Intel", "ball-grid array",8,64);
            Memory m = new Memory(8.7,9.5,"RAM", 250);
            GraphicsCard gc = new GraphicsCard(3,4.5,128,2432);
            Case c = new Case(24,12,24,4,4);

            ComputerFactory computerFactory = new ComputerFactory();
            computerFactory.createComputer("Super Computer");

            ComputerDirector computerDirector = new ComputerDirector();

            ComputerBuilder builder = new ComputerBuilder();
            
                builder.addHardDrive(hd);
                builder.addMotherboard(mb);
                builder.addCPU(cpu);
                builder.addMemory(m);
                builder.addGraphicsCard(gc);
                builder.addCase(c);


                Computer computer = computerDirector.construct(builder);

                Console.WriteLine(computer);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        } // end of main
    }
}
